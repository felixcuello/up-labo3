#ifndef _THREAD_H
#define _THREAD_H

void *ThreadJugador (void *parametro);

#endif


#ifndef _GLO_
#define _GLO_
#include <pthread.h>

extern pthread_mutex_t mutex;

#endif

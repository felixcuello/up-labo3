#ifndef FUNCIONES_H
#define FUNCIONES_H

int generar_numero_random(int min, int max);
int leer_entero();
void leer_cadena(char *variable);

#endif

#include "global.h"

pthread_mutex_t mutex;
